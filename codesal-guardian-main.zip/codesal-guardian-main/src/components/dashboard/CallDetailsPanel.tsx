import { useState } from 'react';
import { 
  Phone, MapPin, ExternalLink, AlertTriangle, Brain, 
  FileText, History, MessageSquare, Users, CheckCircle,
  XCircle, Clock, Droplets, Mountain, TreeDeciduous
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Call, historicalCalls, teams, operators } from '@/data/mockData';
import { RiskBadge } from './RiskBadge';
import { toast } from '@/hooks/use-toast';
import { MiniMap } from './MiniMap';

interface CallDetailsPanelProps {
  call: Call | null;
}

type TabType = 'overview' | 'geotechnical' | 'management';

export const CallDetailsPanel = ({ call }: CallDetailsPanelProps) => {
  const [activeTab, setActiveTab] = useState<TabType>('overview');
  const [newObservation, setNewObservation] = useState('');
  const [aiValidation, setAiValidation] = useState('agree');
  const [validationComment, setValidationComment] = useState('');

  if (!call) {
    return (
      <div className="panel w-96 flex-shrink-0">
        <div className="flex-1 flex items-center justify-center text-muted-foreground">
          <div className="text-center">
            <AlertTriangle className="w-12 h-12 mx-auto mb-3 opacity-30" />
            <p className="text-sm">Selecione um chamado</p>
            <p className="text-xs text-muted-foreground/70">no mapa ou na lista</p>
          </div>
        </div>
      </div>
    );
  }

  const history = historicalCalls[call.neighborhood] || [];

  const handleSaveObservation = () => {
    if (!newObservation.trim()) return;
    toast({
      title: "Observação salva",
      description: "A observação foi registrada com sucesso.",
    });
    setNewObservation('');
  };

  const handleSendFeedback = () => {
    toast({
      title: "Feedback enviado",
      description: "Seu feedback foi registrado para retreinamento da IA.",
    });
    setValidationComment('');
  };

  const tabs = [
    { id: 'overview' as TabType, label: 'Visão Geral', icon: FileText },
    { id: 'geotechnical' as TabType, label: 'Contexto', icon: Mountain },
    { id: 'management' as TabType, label: 'Gestão', icon: Users },
  ];

  return (
    <div className="panel w-96 flex-shrink-0 animate-slide-in-right">
      {/* Panel Header */}
      <div className="panel-header flex-col gap-2">
        <div className="flex items-center justify-between w-full">
          <span className="text-xs font-mono text-muted-foreground">{call.protocol}</span>
          <RiskBadge level={call.riskLevel} />
        </div>
        <h3 className="text-sm font-medium text-foreground w-full">{call.neighborhood}</h3>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-border/50">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`tab-button flex-1 flex items-center justify-center gap-1.5 ${
              activeTab === tab.id ? 'active' : ''
            }`}
          >
            <tab.icon className="w-3.5 h-3.5" />
            <span>{tab.label}</span>
          </button>
        ))}
      </div>

      {/* Tab Content */}
      <div className="panel-content">
        {activeTab === 'overview' && (
          <div className="p-4 space-y-4 animate-fade-in">
            {/* Location Mini Map */}
            <div className="space-y-2">
              <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide flex items-center gap-2">
                <MapPin className="w-3.5 h-3.5" />
                Localização da Ocorrência
              </h4>
              <MiniMap coordinates={call.coordinates} riskLevel={call.riskLevel} />
            </div>

            {/* Photo */}
            <div className="space-y-2">
              <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">
                Foto do WhatsApp
              </h4>
              <div className="relative rounded-lg overflow-hidden border border-border/50">
                <img 
                  src={call.photoUrl} 
                  alt="Foto do chamado"
                  className="w-full h-32 object-cover"
                />
                <button className="absolute top-2 right-2 p-1.5 rounded bg-background/80 hover:bg-background text-foreground">
                  <ExternalLink className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Requester Info */}
            <div className="space-y-2">
              <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">
                Dados do Solicitante
              </h4>
              <div className="bg-secondary/30 rounded-lg p-3 space-y-2">
                <p className="text-sm text-foreground">{call.requesterName}</p>
                <a 
                  href={`https://wa.me/${call.requesterPhone.replace(/\D/g, '')}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 text-xs text-primary hover:underline"
                >
                  <Phone className="w-3.5 h-3.5" />
                  {call.requesterPhone}
                </a>
                <div className="flex items-start gap-2 text-xs text-muted-foreground">
                  <MapPin className="w-3.5 h-3.5 mt-0.5 flex-shrink-0" />
                  <span>{call.address}</span>
                </div>
                <a 
                  href={`https://maps.google.com/?q=${call.coordinates.lat},${call.coordinates.lng}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1 text-[10px] text-primary hover:underline"
                >
                  <ExternalLink className="w-3 h-3" />
                  Ver no Google Maps
                </a>
              </div>
            </div>

            {/* AI Analysis */}
            <div className="space-y-2">
              <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide flex items-center gap-2">
                <Brain className="w-3.5 h-3.5" />
                Análise da IA
              </h4>
              <div className="bg-secondary/30 rounded-lg p-3 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs text-muted-foreground">Classificação:</span>
                  <RiskBadge level={call.riskLevel} size="sm" />
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-xs text-muted-foreground">Confiança:</span>
                  <div className="flex items-center gap-2">
                    <div className="w-24 h-2 bg-secondary rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-primary rounded-full"
                        style={{ width: `${call.aiConfidence}%` }}
                      />
                    </div>
                    <span className="text-xs font-medium text-foreground">{call.aiConfidence}%</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Symptoms */}
            <div className="space-y-2">
              <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">
                Sintomas Reportados
              </h4>
              <div className="flex flex-wrap gap-1.5">
                {call.symptoms.map((symptom, index) => (
                  <span 
                    key={index}
                    className="px-2 py-1 text-[10px] bg-secondary/50 text-foreground rounded-full border border-border/50"
                  >
                    {symptom}
                  </span>
                ))}
              </div>
            </div>

            {/* AI Recommendation */}
            <div className="space-y-2">
              <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">
                Recomendação Pró-Ativa
              </h4>
              <div className={`rounded-lg p-3 border ${
                call.riskLevel === 'critical' 
                  ? 'bg-risk-critical/10 border-risk-critical/30 text-risk-critical'
                  : call.riskLevel === 'high'
                  ? 'bg-risk-high/10 border-risk-high/30 text-risk-high'
                  : 'bg-secondary/30 border-border/50 text-foreground'
              }`}>
                <p className="text-xs leading-relaxed">{call.aiRecommendation}</p>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'geotechnical' && (
          <div className="p-4 space-y-4 animate-fade-in">
            {/* Area Classification */}
            <div className="space-y-2">
              <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">
                Avaliação da Área
              </h4>
              <div className="bg-secondary/30 rounded-lg p-3 space-y-2.5">
                <div className="flex items-start gap-2">
                  <AlertTriangle className="w-4 h-4 text-risk-critical mt-0.5" />
                  <div>
                    <span className="text-[10px] text-muted-foreground">Classificação CODESAL:</span>
                    <p className="text-xs text-foreground font-medium">{call.areaClassification}</p>
                  </div>
                </div>
                <div className="flex items-start gap-2">
                  <Mountain className="w-4 h-4 text-muted-foreground mt-0.5" />
                  <div>
                    <span className="text-[10px] text-muted-foreground">Tipo de Solo:</span>
                    <p className="text-xs text-foreground">{call.soilType}</p>
                  </div>
                </div>
                <div className="flex items-start gap-2">
                  <svg className="w-4 h-4 text-muted-foreground mt-0.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M2 20h20M5 20v-8l7-7 7 7v8" />
                  </svg>
                  <div>
                    <span className="text-[10px] text-muted-foreground">Inclinação:</span>
                    <p className="text-xs text-foreground">{call.slopeAngle}° graus</p>
                  </div>
                </div>
                <div className="flex items-start gap-2">
                  <TreeDeciduous className="w-4 h-4 text-muted-foreground mt-0.5" />
                  <div>
                    <span className="text-[10px] text-muted-foreground">Vegetação:</span>
                    <p className="text-xs text-foreground">{call.vegetation}</p>
                  </div>
                </div>
                <div className="flex items-start gap-2">
                  <Droplets className="w-4 h-4 text-muted-foreground mt-0.5" />
                  <div>
                    <span className="text-[10px] text-muted-foreground">Drenagem:</span>
                    <p className="text-xs text-foreground">{call.drainage}</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Pluviometers */}
            <div className="space-y-2">
              <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">
                Pluviômetros Próximos
              </h4>
              <div className="space-y-1.5">
                {call.nearbyPluviometers.map((plv, index) => (
                  <div 
                    key={index}
                    className="flex items-center justify-between bg-secondary/30 rounded-lg px-3 py-2"
                  >
                    <span className="text-xs font-mono text-foreground">{plv.code}</span>
                    <span className={`text-xs font-medium ${
                      plv.reading > 40 ? 'text-risk-critical' : 
                      plv.reading > 25 ? 'text-risk-high' : 'text-foreground'
                    }`}>
                      {plv.reading} mm/h
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Historical Calls */}
            <div className="space-y-2">
              <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide flex items-center gap-2">
                <History className="w-3.5 h-3.5" />
                Histórico da Área (200m)
              </h4>
              {history.length > 0 ? (
                <div className="space-y-2 max-h-48 overflow-y-auto">
                  {history.map((hist, index) => (
                    <div 
                      key={index}
                      className="bg-secondary/30 rounded-lg p-2.5 border border-border/30 hover:border-border/50 cursor-pointer transition-colors"
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-[10px] font-mono text-muted-foreground">{hist.protocol}</span>
                        <RiskBadge level={hist.riskLevel} size="sm" />
                      </div>
                      <p className="text-xs text-foreground mb-1">{hist.summary}</p>
                      <div className="flex items-center justify-between text-[10px] text-muted-foreground">
                        <span>{hist.date}</span>
                        <span className="text-status-completed">{hist.finalStatus}</span>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-muted-foreground text-center py-4">
                  Sem histórico na área
                </p>
              )}
            </div>
          </div>
        )}

        {activeTab === 'management' && (
          <div className="p-4 space-y-4 animate-fade-in">
            {/* Status Info */}
            <div className="space-y-2">
              <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">
                Status do Chamado
              </h4>
              <div className="bg-secondary/30 rounded-lg p-3 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-muted-foreground">Criado em:</span>
                  <span className="text-foreground">{new Date(call.createdAt).toLocaleString('pt-BR')}</span>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-muted-foreground">Atualizado:</span>
                  <span className="text-foreground">{new Date(call.updatedAt).toLocaleString('pt-BR')}</span>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-muted-foreground">Operador:</span>
                  <Select defaultValue={call.operator || ''}>
                    <SelectTrigger className="h-7 w-36 text-xs">
                      <SelectValue placeholder="Designar" />
                    </SelectTrigger>
                    <SelectContent>
                      {operators.map(op => (
                        <SelectItem key={op} value={op}>{op}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-muted-foreground">Equipe:</span>
                  <Select defaultValue={call.team || ''}>
                    <SelectTrigger className="h-7 w-36 text-xs">
                      <SelectValue placeholder="Designar" />
                    </SelectTrigger>
                    <SelectContent>
                      {teams.map(team => (
                        <SelectItem key={team} value={team}>{team}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>

            {/* Observations */}
            <div className="space-y-2">
              <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide flex items-center gap-2">
                <MessageSquare className="w-3.5 h-3.5" />
                Observações da Equipe
              </h4>
              {call.observations.length > 0 && (
                <div className="space-y-2 max-h-32 overflow-y-auto mb-2">
                  {call.observations.map((obs, index) => (
                    <div key={index} className="bg-secondary/30 rounded-lg p-2.5 text-xs">
                      <p className="text-foreground mb-1">{obs.text}</p>
                      <div className="flex items-center justify-between text-[10px] text-muted-foreground">
                        <span>{obs.author}</span>
                        <span>{new Date(obs.timestamp).toLocaleString('pt-BR')}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
              <Textarea
                placeholder="Adicionar observação..."
                value={newObservation}
                onChange={(e) => setNewObservation(e.target.value)}
                className="bg-secondary/30 border-border/50 text-xs min-h-[80px] resize-none"
              />
              <Button 
                size="sm" 
                className="w-full h-8 text-xs"
                onClick={handleSaveObservation}
              >
                Salvar Observação
              </Button>
            </div>

            {/* AI Validation */}
            <div className="space-y-2">
              <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide flex items-center gap-2">
                <Brain className="w-3.5 h-3.5" />
                Validação da IA (Feedback)
              </h4>
              <div className="bg-secondary/30 rounded-lg p-3 space-y-3">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-muted-foreground">Classificação IA:</span>
                  <RiskBadge level={call.riskLevel} size="sm" />
                </div>
                <div className="space-y-1.5">
                  <span className="text-xs text-muted-foreground">Sua validação:</span>
                  <Select value={aiValidation} onValueChange={setAiValidation}>
                    <SelectTrigger className="h-8 text-xs">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="agree">✓ Concorda</SelectItem>
                      <SelectItem value="medium">↓ Discorda (Risco Médio)</SelectItem>
                      <SelectItem value="low">↓ Discorda (Risco Baixo)</SelectItem>
                      <SelectItem value="false_alarm">✗ Falso Alarme</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Textarea
                  placeholder="Comentário para IA (opcional)..."
                  value={validationComment}
                  onChange={(e) => setValidationComment(e.target.value)}
                  className="bg-background/50 border-border/50 text-xs min-h-[60px] resize-none"
                />
                <Button 
                  size="sm" 
                  variant="outline"
                  className="w-full h-8 text-xs"
                  onClick={handleSendFeedback}
                >
                  Enviar Feedback para IA
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Action Buttons Footer */}
      <div className="p-3 border-t border-border/50 space-y-2">
        <div className="grid grid-cols-2 gap-2">
          <Button size="sm" className="h-9 text-xs gap-1.5">
            <Users className="w-3.5 h-3.5" />
            Designar Equipe
          </Button>
          <Select defaultValue={call.status}>
            <SelectTrigger className="h-9 text-xs">
              <SelectValue placeholder="Mudar Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="new">Novo</SelectItem>
              <SelectItem value="in_progress">Em Vistoria</SelectItem>
              <SelectItem value="completed">Concluído</SelectItem>
              <SelectItem value="cancelled">Cancelado</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <Button 
          size="sm" 
          variant="outline" 
          className="w-full h-9 text-xs text-risk-critical border-risk-critical/30 hover:bg-risk-critical/10"
        >
          <XCircle className="w-3.5 h-3.5 mr-1.5" />
          Fechar Chamado
        </Button>
      </div>
    </div>
  );
};
