import { Shield, Settings, User } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { NavLink } from '@/components/NavLink';
import { NotificationsPanel } from './NotificationsPanel';
import { useNavigate } from 'react-router-dom';

export const Header = () => {
  const navigate = useNavigate();

  return (
    <header className="flex items-center justify-between px-6 py-3 bg-card/80 backdrop-blur-sm border-b border-border/50">
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-primary/10 border border-primary/20">
            <Shield className="w-6 h-6 text-primary" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-foreground tracking-tight">
              ECO-BYTES
            </h1>
            <p className="text-xs text-muted-foreground">
              Dashboard Tático de Priorização
            </p>
          </div>
        </div>
        <div className="h-8 w-px bg-border/50 mx-4" />
        <nav className="flex items-center gap-1">
          <NavLink 
            to="/" 
            className="px-3 py-2 text-sm rounded-md transition-colors text-muted-foreground hover:text-foreground hover:bg-secondary/50"
            activeClassName="text-foreground bg-secondary/50"
          >
            Visão Geral
          </NavLink>
          <NavLink 
            to="/prioridades" 
            className="px-3 py-2 text-sm rounded-md transition-colors text-muted-foreground hover:text-foreground hover:bg-secondary/50"
            activeClassName="text-foreground bg-secondary/50"
          >
            Lista de Prioridades
          </NavLink>
          <NavLink 
            to="/relatorios" 
            className="px-3 py-2 text-sm rounded-md transition-colors text-muted-foreground hover:text-foreground hover:bg-secondary/50"
            activeClassName="text-foreground bg-secondary/50"
          >
            Relatórios
          </NavLink>
        </nav>
      </div>

      <div className="flex items-center gap-3">
        <NotificationsPanel />
        <Button 
          variant="ghost" 
          size="icon"
          onClick={() => navigate('/configuracoes')}
        >
          <Settings className="w-5 h-5 text-muted-foreground" />
        </Button>
        <div className="h-6 w-px bg-border/50" />
        <div className="flex items-center gap-3 px-3 py-1.5 rounded-lg bg-secondary/50">
          <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center">
            <User className="w-4 h-4 text-primary" />
          </div>
          <div className="text-right">
            <p className="text-sm font-medium text-foreground">Operador</p>
            <p className="text-xs text-muted-foreground">CODESAL</p>
          </div>
        </div>
      </div>
    </header>
  );
};