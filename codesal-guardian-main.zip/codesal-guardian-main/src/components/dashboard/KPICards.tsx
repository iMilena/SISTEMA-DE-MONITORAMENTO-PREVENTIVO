import { AlertTriangle, Calendar, Clock, CheckCircle, FolderOpen, MapPin } from 'lucide-react';
import { kpiData } from '@/data/mockData';

interface KPICardProps {
  icon: React.ReactNode;
  label: string;
  value: string | number;
  subtext?: string;
  variant?: 'default' | 'alert' | 'success';
}

const KPICard = ({ icon, label, value, subtext, variant = 'default' }: KPICardProps) => {
  const variantStyles = {
    default: 'border-border/50',
    alert: 'border-risk-critical/30 bg-risk-critical/5',
    success: 'border-risk-low/30 bg-risk-low/5'
  };

  const iconVariant = {
    default: 'text-primary',
    alert: 'text-risk-critical',
    success: 'text-risk-low'
  };

  return (
    <div className={`kpi-card ${variantStyles[variant]}`}>
      <div className="flex items-start justify-between">
        <div className={`p-2 rounded-lg bg-secondary/50 ${iconVariant[variant]}`}>
          {icon}
        </div>
        {variant === 'alert' && (
          <span className="w-2 h-2 rounded-full bg-risk-critical animate-pulse" />
        )}
      </div>
      <div className="mt-3">
        <p className="text-2xl font-bold text-foreground">{value}</p>
        <p className="text-xs text-muted-foreground mt-0.5">{label}</p>
        {subtext && (
          <p className="text-[10px] text-muted-foreground/70 mt-1">{subtext}</p>
        )}
      </div>
    </div>
  );
};

export const KPICards = () => {
  return (
    <div className="grid grid-cols-6 gap-4 px-6 py-4 border-b border-border/50 bg-background/50">
      <KPICard
        icon={<AlertTriangle className="w-5 h-5" />}
        label="Prioritários Ativos"
        value={kpiData.activePriorities}
        subtext="Requer atenção imediata"
        variant="alert"
      />
      <KPICard
        icon={<Calendar className="w-5 h-5" />}
        label="Chamados Hoje"
        value={kpiData.dailyCalls}
        subtext="Últimas 24 horas"
      />
      <KPICard
        icon={<Clock className="w-5 h-5" />}
        label="Tempo Médio Resposta"
        value={`${kpiData.avgResponseTime} min`}
        subtext="Meta: 30 min"
      />
      <KPICard
        icon={<CheckCircle className="w-5 h-5" />}
        label="Concluídos (Mês)"
        value={kpiData.monthlyCompleted}
        variant="success"
      />
      <KPICard
        icon={<FolderOpen className="w-5 h-5" />}
        label="Total Abertos"
        value={kpiData.totalOpen}
      />
      <KPICard
        icon={<MapPin className="w-5 h-5" />}
        label="Chamados por Área"
        value="Ver Mapa"
        subtext="Mapa de calor"
      />
    </div>
  );
};
