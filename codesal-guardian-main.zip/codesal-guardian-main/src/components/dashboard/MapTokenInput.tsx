import { useState } from 'react';
import { Key, ExternalLink, Check, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useMapbox } from '@/contexts/MapboxContext';

export const MapTokenInput = () => {
  const { token, setToken, isTokenValid } = useMapbox();
  const [inputValue, setInputValue] = useState(token);
  const [isEditing, setIsEditing] = useState(!isTokenValid);

  const handleSave = () => {
    setToken(inputValue);
    setIsEditing(false);
  };

  if (isTokenValid && !isEditing) {
    return (
      <div className="flex items-center gap-2 px-3 py-1.5 bg-status-completed/10 border border-status-completed/30 rounded-lg">
        <Check className="w-3.5 h-3.5 text-status-completed" />
        <span className="text-xs text-status-completed">Mapbox conectado</span>
        <button 
          onClick={() => setIsEditing(true)}
          className="text-[10px] text-muted-foreground hover:text-foreground ml-2"
        >
          Alterar
        </button>
      </div>
    );
  }

  return (
    <div className="flex items-center gap-2">
      <div className="flex items-center gap-1.5 px-2 py-1 bg-risk-high/10 border border-risk-high/30 rounded-lg">
        <Key className="w-3.5 h-3.5 text-risk-high" />
        <Input
          type="text"
          placeholder="Cole seu token Mapbox (pk.xxx)"
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          className="h-6 w-64 text-xs bg-transparent border-0 p-0 focus-visible:ring-0"
        />
        {inputValue && (
          <Button 
            size="sm" 
            variant="ghost" 
            className="h-5 w-5 p-0"
            onClick={handleSave}
          >
            <Check className="w-3 h-3" />
          </Button>
        )}
        {isEditing && isTokenValid && (
          <Button 
            size="sm" 
            variant="ghost" 
            className="h-5 w-5 p-0"
            onClick={() => {
              setInputValue(token);
              setIsEditing(false);
            }}
          >
            <X className="w-3 h-3" />
          </Button>
        )}
      </div>
      <a
        href="https://account.mapbox.com/access-tokens/"
        target="_blank"
        rel="noopener noreferrer"
        className="flex items-center gap-1 text-[10px] text-primary hover:underline"
      >
        <ExternalLink className="w-3 h-3" />
        Obter token
      </a>
    </div>
  );
};
