import { useState, useEffect, useRef } from 'react';
import mapboxgl from 'mapbox-gl';
import 'mapbox-gl/dist/mapbox-gl.css';
import { Layers, Thermometer, CloudRain, AlertTriangle, Navigation } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Call, pluviometers, getPluviometerColor } from '@/data/mockData';
import { useMapbox } from '@/contexts/MapboxContext';
import { MapTokenInput } from './MapTokenInput';
import { WeatherForecastPanel } from './WeatherForecastPanel';

interface MapViewProps {
  calls: Call[];
  selectedCall: Call | null;
  onSelectCall: (call: Call) => void;
}

const riskColors = {
  critical: '#ef4444',
  high: '#f97316',
  medium: '#eab308',
  low: '#22c55e',
};

export const MapView = ({ calls, selectedCall, onSelectCall }: MapViewProps) => {
  const mapContainer = useRef<HTMLDivElement>(null);
  const map = useRef<mapboxgl.Map | null>(null);
  const markersRef = useRef<mapboxgl.Marker[]>([]);
  const pluviometerMarkersRef = useRef<mapboxgl.Marker[]>([]);
  const { token, isTokenValid } = useMapbox();
  
  const [activeLayers, setActiveLayers] = useState({
    heatmap: true,
    riskAreas: true,
    pluviometers: true,
    forecast: true,
  });

  const toggleLayer = (layer: keyof typeof activeLayers) => {
    setActiveLayers(prev => ({ ...prev, [layer]: !prev[layer] }));
  };

  // Initialize map
  useEffect(() => {
    if (!mapContainer.current || !isTokenValid) return;

    mapboxgl.accessToken = token;

    map.current = new mapboxgl.Map({
      container: mapContainer.current,
      style: 'mapbox://styles/mapbox/dark-v11',
      center: [-38.5014, -12.9714],
      zoom: 11.5,
      pitch: 45,
      bearing: -10,
    });

    map.current.addControl(
      new mapboxgl.NavigationControl({ visualizePitch: true }),
      'top-right'
    );

    map.current.addControl(
      new mapboxgl.ScaleControl({ maxWidth: 100 }),
      'bottom-left'
    );

    // Add 3D buildings and atmosphere on load
    map.current.on('load', () => {
      if (!map.current) return;

      // Atmosphere effect
      map.current.setFog({
        color: 'rgb(20, 20, 30)',
        'high-color': 'rgb(30, 30, 50)',
        'horizon-blend': 0.1,
        'star-intensity': 0.15,
      });

      // 3D buildings
      map.current.addLayer({
        id: '3d-buildings',
        source: 'composite',
        'source-layer': 'building',
        filter: ['==', 'extrude', 'true'],
        type: 'fill-extrusion',
        minzoom: 12,
        paint: {
          'fill-extrusion-color': '#1a1a2e',
          'fill-extrusion-height': ['get', 'height'],
          'fill-extrusion-base': ['get', 'min_height'],
          'fill-extrusion-opacity': 0.7,
        },
      });

      // Risk areas layer
      map.current.addSource('risk-areas', {
        type: 'geojson',
        data: {
          type: 'FeatureCollection',
          features: [
            {
              type: 'Feature',
              properties: { risk: 'high' },
              geometry: {
                type: 'Polygon',
                coordinates: [[
                  [-38.52, -12.95],
                  [-38.50, -12.95],
                  [-38.50, -12.97],
                  [-38.52, -12.97],
                  [-38.52, -12.95],
                ]],
              },
            },
            {
              type: 'Feature',
              properties: { risk: 'critical' },
              geometry: {
                type: 'Polygon',
                coordinates: [[
                  [-38.48, -12.98],
                  [-38.46, -12.98],
                  [-38.46, -13.00],
                  [-38.48, -13.00],
                  [-38.48, -12.98],
                ]],
              },
            },
          ],
        },
      });

      map.current.addLayer({
        id: 'risk-areas-fill',
        type: 'fill',
        source: 'risk-areas',
        paint: {
          'fill-color': [
            'match',
            ['get', 'risk'],
            'critical', riskColors.critical,
            'high', riskColors.high,
            riskColors.medium,
          ],
          'fill-opacity': 0.2,
        },
      });

      map.current.addLayer({
        id: 'risk-areas-line',
        type: 'line',
        source: 'risk-areas',
        paint: {
          'line-color': [
            'match',
            ['get', 'risk'],
            'critical', riskColors.critical,
            'high', riskColors.high,
            riskColors.medium,
          ],
          'line-width': 2,
          'line-dasharray': [2, 2],
        },
      });

      // Heatmap layer
      map.current.addSource('calls-heat', {
        type: 'geojson',
        data: {
          type: 'FeatureCollection',
          features: calls.map(call => ({
            type: 'Feature' as const,
            properties: {
              intensity: call.riskLevel === 'critical' ? 1 : 
                         call.riskLevel === 'high' ? 0.7 : 
                         call.riskLevel === 'medium' ? 0.4 : 0.2,
            },
            geometry: {
              type: 'Point' as const,
              coordinates: [call.coordinates.lng, call.coordinates.lat],
            },
          })),
        },
      });

      map.current.addLayer({
        id: 'calls-heatmap',
        type: 'heatmap',
        source: 'calls-heat',
        paint: {
          'heatmap-weight': ['get', 'intensity'],
          'heatmap-intensity': 1,
          'heatmap-color': [
            'interpolate',
            ['linear'],
            ['heatmap-density'],
            0, 'rgba(0,0,0,0)',
            0.2, 'rgba(34,197,94,0.3)',
            0.4, 'rgba(234,179,8,0.5)',
            0.6, 'rgba(249,115,22,0.7)',
            0.8, 'rgba(239,68,68,0.85)',
            1, 'rgba(239,68,68,1)',
          ],
          'heatmap-radius': 40,
          'heatmap-opacity': 0.8,
        },
      });
    });

    return () => {
      map.current?.remove();
    };
  }, [token, isTokenValid]);

  // Toggle layers visibility
  useEffect(() => {
    if (!map.current || !map.current.isStyleLoaded()) return;

    try {
      if (map.current.getLayer('calls-heatmap')) {
        map.current.setLayoutProperty(
          'calls-heatmap',
          'visibility',
          activeLayers.heatmap ? 'visible' : 'none'
        );
      }
      if (map.current.getLayer('risk-areas-fill')) {
        map.current.setLayoutProperty(
          'risk-areas-fill',
          'visibility',
          activeLayers.riskAreas ? 'visible' : 'none'
        );
        map.current.setLayoutProperty(
          'risk-areas-line',
          'visibility',
          activeLayers.riskAreas ? 'visible' : 'none'
        );
      }
    } catch (e) {
      // Layers not ready yet
    }
  }, [activeLayers.heatmap, activeLayers.riskAreas]);

  // Add/remove pluviometer markers
  useEffect(() => {
    if (!map.current || !isTokenValid) return;
    pluviometerMarkersRef.current.forEach(marker => marker.remove());
    pluviometerMarkersRef.current = [];
    if (!activeLayers.pluviometers) return;

    pluviometers.forEach(pluviometer => {
      const el = document.createElement('div');
      el.className = 'pluviometer-marker';
      const color = getPluviometerColor(pluviometer.reading);
      el.innerHTML = `
        <div class="pluviometer-container">
          <div class="pluviometer-icon" style="background: ${color}; box-shadow: 0 0 10px ${color}40;">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M12 2.69l5.66 5.66a8 8 0 1 1-11.31 0z"/>
            </svg>
          </div>
          <div class="pluviometer-label">${pluviometer.reading.toFixed(1)}</div>
        </div>
      `;
      const popup = new mapboxgl.Popup({ offset: 25, closeButton: false, className: 'pluviometer-popup' })
        .setHTML(`<div class="p-2"><div class="font-semibold">${pluviometer.name}</div><div class="text-xs opacity-70">${pluviometer.code}</div><div class="mt-1"><span class="font-bold" style="color: ${color}">${pluviometer.reading} mm/h</span></div></div>`);
      const marker = new mapboxgl.Marker(el)
        .setLngLat([pluviometer.coordinates.lng, pluviometer.coordinates.lat])
        .setPopup(popup)
        .addTo(map.current!);
      pluviometerMarkersRef.current.push(marker);
    });
  }, [activeLayers.pluviometers, isTokenValid]);

  // Add markers for calls
  useEffect(() => {
    if (!map.current || !isTokenValid) return;

    // Clear existing markers
    markersRef.current.forEach(marker => marker.remove());
    markersRef.current = [];

    calls.forEach(call => {
      const el = document.createElement('div');
      el.className = 'call-marker';
      
      const isSelected = selectedCall?.id === call.id;
      const isCritical = call.riskLevel === 'critical';
      
      el.innerHTML = `
        <div class="marker-container ${isSelected ? 'selected' : ''} ${isCritical ? 'critical' : ''}">
          ${isCritical ? '<div class="ping"></div>' : ''}
          <div class="marker-dot" style="background: ${riskColors[call.riskLevel]}"></div>
          ${isSelected ? '<div class="selection-ring" style="border-color: ' + riskColors[call.riskLevel] + '"></div>' : ''}
        </div>
      `;

      el.addEventListener('click', () => onSelectCall(call));

      const marker = new mapboxgl.Marker(el)
        .setLngLat([call.coordinates.lng, call.coordinates.lat])
        .addTo(map.current!);

      markersRef.current.push(marker);
    });
  }, [calls, selectedCall, onSelectCall, isTokenValid]);

  // Fly to selected call
  useEffect(() => {
    if (!map.current || !selectedCall || !isTokenValid) return;

    map.current.flyTo({
      center: [selectedCall.coordinates.lng, selectedCall.coordinates.lat],
      zoom: 15,
      pitch: 60,
      duration: 1500,
      essential: true,
    });
  }, [selectedCall, isTokenValid]);

  return (
    <div className="flex-1 flex flex-col h-full">
      {/* Map Layer Controls */}
      <div className="flex items-center justify-between gap-2 px-4 py-2 border-b border-border/50 bg-card/50">
        <div className="flex items-center gap-2">
          <span className="text-xs text-muted-foreground mr-2">Camadas:</span>
          <Button
            variant={activeLayers.heatmap ? "default" : "outline"}
            size="sm"
            className="h-7 text-xs gap-1.5"
            onClick={() => toggleLayer('heatmap')}
          >
            <Thermometer className="w-3.5 h-3.5" />
            Mapa de Calor
          </Button>
          <Button
            variant={activeLayers.riskAreas ? "default" : "outline"}
            size="sm"
            className="h-7 text-xs gap-1.5"
            onClick={() => toggleLayer('riskAreas')}
          >
            <AlertTriangle className="w-3.5 h-3.5" />
            Áreas de Risco
          </Button>
          <Button
            variant={activeLayers.pluviometers ? "default" : "outline"}
            size="sm"
            className="h-7 text-xs gap-1.5"
            onClick={() => toggleLayer('pluviometers')}
          >
            <CloudRain className="w-3.5 h-3.5" />
            Pluviômetros
          </Button>
          <Button
            variant={activeLayers.forecast ? "default" : "outline"}
            size="sm"
            className="h-7 text-xs gap-1.5"
            onClick={() => toggleLayer('forecast')}
          >
            <Layers className="w-3.5 h-3.5" />
            Previsão
          </Button>
        </div>
        <MapTokenInput />
      </div>

      {/* Map Container */}
      <div className="flex-1 relative m-4">
        {isTokenValid ? (
          <>
            <div ref={mapContainer} className="absolute inset-0 rounded-xl overflow-hidden" />
            
            {/* Weather Forecast Panel */}
            {activeLayers.forecast && <WeatherForecastPanel />}
            
            {/* Legend */}
            <div className="absolute bottom-4 left-4 bg-card/90 backdrop-blur-sm rounded-lg p-3 border border-border/50">
              <div className="flex items-center gap-2 mb-2">
                <Navigation className="w-4 h-4 text-primary" />
                <span className="text-xs font-medium text-foreground">Salvador, BA</span>
              </div>
              <div className="flex items-center gap-4">
                {Object.entries(riskColors).map(([level, color]) => (
                  <div key={level} className="flex items-center gap-1.5">
                    <div 
                      className="w-2.5 h-2.5 rounded-full"
                      style={{ backgroundColor: color }}
                    />
                    <span className="text-[10px] text-muted-foreground capitalize">
                      {level === 'critical' ? 'Crítico' : level === 'high' ? 'Alto' : level === 'medium' ? 'Médio' : 'Baixo'}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </>
        ) : (
          <div className="absolute inset-0 rounded-xl overflow-hidden bg-secondary/30 flex items-center justify-center border border-border/50">
            <div className="text-center max-w-md p-8">
              <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-primary/10 flex items-center justify-center">
                <Navigation className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-2">Configure o Mapbox</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Para visualizar o mapa interativo de Salvador, insira seu token público do Mapbox no campo acima.
              </p>
              <a
                href="https://account.mapbox.com/access-tokens/"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 text-sm text-primary hover:underline"
              >
                Obter token gratuito no Mapbox
              </a>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
