import { useEffect, useRef } from 'react';
import mapboxgl from 'mapbox-gl';
import 'mapbox-gl/dist/mapbox-gl.css';
import { useMapbox } from '@/contexts/MapboxContext';
import { MapPin } from 'lucide-react';

interface MiniMapProps {
  coordinates: { lat: number; lng: number };
  riskLevel: 'critical' | 'high' | 'medium' | 'low';
}

const riskColors = {
  critical: '#ef4444',
  high: '#f97316',
  medium: '#eab308',
  low: '#22c55e',
};

export const MiniMap = ({ coordinates, riskLevel }: MiniMapProps) => {
  const mapContainer = useRef<HTMLDivElement>(null);
  const map = useRef<mapboxgl.Map | null>(null);
  const marker = useRef<mapboxgl.Marker | null>(null);
  const { token, isTokenValid } = useMapbox();

  useEffect(() => {
    if (!mapContainer.current || !isTokenValid) return;

    mapboxgl.accessToken = token;

    map.current = new mapboxgl.Map({
      container: mapContainer.current,
      style: 'mapbox://styles/mapbox/dark-v11',
      center: [coordinates.lng, coordinates.lat],
      zoom: 15,
      interactive: false,
      attributionControl: false,
    });

    // Add marker
    const el = document.createElement('div');
    el.className = 'mini-map-marker';
    el.style.cssText = `
      width: 24px;
      height: 24px;
      background: ${riskColors[riskLevel]};
      border: 3px solid white;
      border-radius: 50%;
      box-shadow: 0 0 20px ${riskColors[riskLevel]}, 0 2px 8px rgba(0,0,0,0.5);
      animation: pulse 2s infinite;
    `;

    marker.current = new mapboxgl.Marker(el)
      .setLngLat([coordinates.lng, coordinates.lat])
      .addTo(map.current);

    // Add radius circle
    map.current.on('load', () => {
      if (!map.current) return;
      
      map.current.addSource('radius', {
        type: 'geojson',
        data: {
          type: 'Feature',
          properties: {},
          geometry: {
            type: 'Point',
            coordinates: [coordinates.lng, coordinates.lat],
          },
        },
      });

      map.current.addLayer({
        id: 'radius-fill',
        type: 'circle',
        source: 'radius',
        paint: {
          'circle-radius': 60,
          'circle-color': riskColors[riskLevel],
          'circle-opacity': 0.15,
          'circle-stroke-color': riskColors[riskLevel],
          'circle-stroke-width': 2,
          'circle-stroke-opacity': 0.4,
        },
      });
    });

    return () => {
      marker.current?.remove();
      map.current?.remove();
    };
  }, [coordinates, riskLevel, token, isTokenValid]);

  if (!isTokenValid) {
    return (
      <div className="relative rounded-lg overflow-hidden border border-border/50 h-32 bg-secondary/30 flex items-center justify-center">
        <div className="text-center text-muted-foreground">
          <MapPin className="w-6 h-6 mx-auto mb-1 opacity-50" />
          <p className="text-[10px]">Configure o token Mapbox</p>
        </div>
      </div>
    );
  }

  return (
    <div className="relative rounded-lg overflow-hidden border border-border/50 h-32">
      <div ref={mapContainer} className="absolute inset-0" />
      <div className="absolute inset-0 pointer-events-none border border-border/20 rounded-lg" />
      <div className="absolute bottom-1 left-1 px-1.5 py-0.5 bg-background/80 backdrop-blur-sm rounded text-[9px] text-muted-foreground">
        {coordinates.lat.toFixed(4)}, {coordinates.lng.toFixed(4)}
      </div>
    </div>
  );
};
