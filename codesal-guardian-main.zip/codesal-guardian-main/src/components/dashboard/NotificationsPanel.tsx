import { useState } from 'react';
import { Bell, X, AlertTriangle, CheckCircle, Clock, MapPin } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { ScrollArea } from '@/components/ui/scroll-area';

interface Notification {
  id: string;
  type: 'critical' | 'warning' | 'info' | 'success';
  title: string;
  message: string;
  location?: string;
  timestamp: string;
  read: boolean;
}

const initialNotifications: Notification[] = [
  {
    id: '1',
    type: 'critical',
    title: 'ALERTA CRÍTICO - Deslizamento Iminente',
    message: 'Área de Bom Juá apresenta sinais de deslizamento. Evacuação recomendada.',
    location: 'Bom Juá',
    timestamp: '2024-01-15T09:30:00',
    read: false,
  },
  {
    id: '2',
    type: 'critical',
    title: 'Chuva Acima do Limiar',
    message: 'Pluviômetro PLV-002 registrando 52.3mm/h - Nível crítico atingido.',
    location: 'Bom Juá',
    timestamp: '2024-01-15T09:15:00',
    read: false,
  },
  {
    id: '3',
    type: 'warning',
    title: 'Novo Chamado de Alto Risco',
    message: 'Chamado COD-2024-001235 classificado como alto risco pela IA.',
    location: 'Engenho Velho de Brotas',
    timestamp: '2024-01-15T08:45:00',
    read: false,
  },
  {
    id: '4',
    type: 'info',
    title: 'Equipe Alpha Designada',
    message: 'Equipe Alpha foi designada para o chamado COD-2024-001234.',
    timestamp: '2024-01-15T08:30:00',
    read: true,
  },
  {
    id: '5',
    type: 'success',
    title: 'Chamado Concluído',
    message: 'Chamado COD-2024-001230 foi marcado como concluído.',
    timestamp: '2024-01-15T08:00:00',
    read: true,
  },
];

export const NotificationsPanel = () => {
  const [notifications, setNotifications] = useState<Notification[]>(initialNotifications);
  const [isOpen, setIsOpen] = useState(false);

  const unreadCount = notifications.filter(n => !n.read).length;

  const markAsRead = (id: string) => {
    setNotifications(prev =>
      prev.map(n => (n.id === id ? { ...n, read: true } : n))
    );
  };

  const markAllAsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  };

  const removeNotification = (id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };

  const getTypeStyles = (type: Notification['type']) => {
    switch (type) {
      case 'critical':
        return {
          bg: 'bg-risk-critical/10',
          border: 'border-risk-critical/30',
          icon: <AlertTriangle className="w-4 h-4 text-risk-critical" />,
          dot: 'bg-risk-critical',
        };
      case 'warning':
        return {
          bg: 'bg-risk-high/10',
          border: 'border-risk-high/30',
          icon: <AlertTriangle className="w-4 h-4 text-risk-high" />,
          dot: 'bg-risk-high',
        };
      case 'success':
        return {
          bg: 'bg-risk-low/10',
          border: 'border-risk-low/30',
          icon: <CheckCircle className="w-4 h-4 text-risk-low" />,
          dot: 'bg-risk-low',
        };
      default:
        return {
          bg: 'bg-primary/10',
          border: 'border-primary/30',
          icon: <Clock className="w-4 h-4 text-primary" />,
          dot: 'bg-primary',
        };
    }
  };

  const formatTime = (timestamp: string) => {
    const date = new Date(timestamp);
    return date.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <Popover open={isOpen} onOpenChange={setIsOpen}>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="icon" className="relative">
          <Bell className="w-5 h-5 text-muted-foreground" />
          {unreadCount > 0 && (
            <span className="absolute -top-1 -right-1 w-5 h-5 bg-risk-critical rounded-full text-[10px] font-bold flex items-center justify-center animate-pulse text-white">
              {unreadCount}
            </span>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-96 p-0 bg-card border-border" align="end">
        <div className="flex items-center justify-between p-4 border-b border-border/50">
          <div>
            <h3 className="font-semibold text-foreground">Notificações</h3>
            <p className="text-xs text-muted-foreground">
              {unreadCount} não lidas
            </p>
          </div>
          {unreadCount > 0 && (
            <Button
              variant="ghost"
              size="sm"
              className="text-xs text-primary"
              onClick={markAllAsRead}
            >
              Marcar todas como lidas
            </Button>
          )}
        </div>

        <ScrollArea className="h-[400px]">
          <div className="p-2 space-y-2">
            {notifications.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <Bell className="w-8 h-8 mx-auto mb-2 opacity-50" />
                <p className="text-sm">Nenhuma notificação</p>
              </div>
            ) : (
              notifications.map(notification => {
                const styles = getTypeStyles(notification.type);
                return (
                  <div
                    key={notification.id}
                    className={`relative p-3 rounded-lg border transition-colors cursor-pointer ${styles.bg} ${styles.border} ${
                      !notification.read ? 'ring-1 ring-primary/20' : 'opacity-70'
                    }`}
                    onClick={() => markAsRead(notification.id)}
                  >
                    <button
                      className="absolute top-2 right-2 p-1 rounded-full hover:bg-secondary/50 transition-colors"
                      onClick={e => {
                        e.stopPropagation();
                        removeNotification(notification.id);
                      }}
                    >
                      <X className="w-3 h-3 text-muted-foreground" />
                    </button>

                    <div className="flex items-start gap-3 pr-6">
                      <div className="mt-0.5">{styles.icon}</div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          {!notification.read && (
                            <div className={`w-2 h-2 rounded-full ${styles.dot}`} />
                          )}
                          <h4 className="text-sm font-medium text-foreground truncate">
                            {notification.title}
                          </h4>
                        </div>
                        <p className="text-xs text-muted-foreground mb-2">
                          {notification.message}
                        </p>
                        <div className="flex items-center justify-between">
                          {notification.location && (
                            <div className="flex items-center gap-1 text-[10px] text-muted-foreground">
                              <MapPin className="w-3 h-3" />
                              {notification.location}
                            </div>
                          )}
                          <span className="text-[10px] text-muted-foreground">
                            {formatTime(notification.timestamp)}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </ScrollArea>
      </PopoverContent>
    </Popover>
  );
};