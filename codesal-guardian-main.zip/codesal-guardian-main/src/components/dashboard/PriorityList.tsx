import { useState } from 'react';
import { Search, Filter, Clock, Droplets, MapPin } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Call, RiskLevel } from '@/data/mockData';
import { RiskBadge } from './RiskBadge';

interface PriorityListProps {
  calls: Call[];
  selectedCall: Call | null;
  onSelectCall: (call: Call) => void;
}

export const PriorityList = ({ calls, selectedCall, onSelectCall }: PriorityListProps) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [riskFilter, setRiskFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  const filteredCalls = calls.filter(call => {
    const matchesSearch = 
      call.protocol.toLowerCase().includes(searchTerm.toLowerCase()) ||
      call.neighborhood.toLowerCase().includes(searchTerm.toLowerCase()) ||
      call.address.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesRisk = riskFilter === 'all' || call.riskLevel === riskFilter;
    const matchesStatus = statusFilter === 'all' || call.status === statusFilter;

    return matchesSearch && matchesRisk && matchesStatus;
  });

  const sortedCalls = [...filteredCalls].sort((a, b) => {
    const riskOrder: Record<RiskLevel, number> = { critical: 0, high: 1, medium: 2, low: 3 };
    return riskOrder[a.riskLevel] - riskOrder[b.riskLevel];
  });

  const formatWaitTime = (minutes: number) => {
    if (minutes < 60) return `${minutes} min`;
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return `${hours}h ${mins}m`;
  };

  const getStatusLabel = (status: string) => {
    const labels: Record<string, string> = {
      new: 'Novo',
      in_progress: 'Em Vistoria',
      completed: 'Concluído',
      cancelled: 'Cancelado'
    };
    return labels[status] || status;
  };

  return (
    <div className="panel w-80 flex-shrink-0">
      <div className="panel-header flex-col gap-3">
        <div className="flex items-center justify-between w-full">
          <h2 className="text-sm font-semibold text-foreground">Lista de Prioridades</h2>
          <span className="text-xs text-muted-foreground bg-secondary px-2 py-0.5 rounded-full">
            {sortedCalls.length} chamados
          </span>
        </div>
        <div className="relative w-full">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Buscar protocolo, bairro..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-9 bg-secondary/50 border-border/50 h-9 text-sm"
          />
        </div>
        <div className="flex gap-2 w-full">
          <Select value={riskFilter} onValueChange={setRiskFilter}>
            <SelectTrigger className="h-8 text-xs bg-secondary/50 border-border/50 flex-1">
              <SelectValue placeholder="Risco" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos os Riscos</SelectItem>
              <SelectItem value="critical">Crítico</SelectItem>
              <SelectItem value="high">Alto</SelectItem>
              <SelectItem value="medium">Médio</SelectItem>
              <SelectItem value="low">Baixo</SelectItem>
            </SelectContent>
          </Select>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="h-8 text-xs bg-secondary/50 border-border/50 flex-1">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos os Status</SelectItem>
              <SelectItem value="new">Novo</SelectItem>
              <SelectItem value="in_progress">Em Vistoria</SelectItem>
              <SelectItem value="completed">Concluído</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="panel-content p-2 space-y-2">
        {sortedCalls.map((call) => (
          <div
            key={call.id}
            onClick={() => onSelectCall(call)}
            className={`priority-item ${selectedCall?.id === call.id ? 'active' : ''}`}
          >
            <div className="flex items-start justify-between gap-2 mb-2">
              <RiskBadge level={call.riskLevel} size="sm" />
              <span className="text-[10px] text-muted-foreground font-mono">
                {call.protocol}
              </span>
            </div>
            
            <div className="flex items-center gap-1.5 text-xs text-foreground mb-1">
              <MapPin className="w-3 h-3 text-muted-foreground flex-shrink-0" />
              <span className="truncate">{call.neighborhood}</span>
            </div>
            
            <p className="text-[11px] text-muted-foreground truncate mb-2">
              {call.address}
            </p>

            <div className="flex items-center justify-between text-[10px]">
              <div className="flex items-center gap-1 text-muted-foreground">
                <Droplets className="w-3 h-3" />
                <span>{call.rainfall} mm/h</span>
              </div>
              <div className="flex items-center gap-1 text-muted-foreground">
                <Clock className="w-3 h-3" />
                <span>{formatWaitTime(call.waitTime)}</span>
              </div>
              <span className={`px-1.5 py-0.5 rounded text-[10px] ${
                call.status === 'new' 
                  ? 'bg-status-new/20 text-status-new' 
                  : call.status === 'in_progress'
                  ? 'bg-status-progress/20 text-status-progress'
                  : 'bg-status-completed/20 text-status-completed'
              }`}>
                {getStatusLabel(call.status)}
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
