import { RiskLevel } from '@/data/mockData';

interface RiskBadgeProps {
  level: RiskLevel;
  size?: 'sm' | 'md' | 'lg';
}

const riskConfig = {
  critical: {
    label: 'CRÍTICO',
    className: 'risk-badge-critical',
  },
  high: {
    label: 'ALTO',
    className: 'risk-badge-high',
  },
  medium: {
    label: 'MÉDIO',
    className: 'risk-badge-medium',
  },
  low: {
    label: 'BAIXO',
    className: 'risk-badge-low',
  },
};

const sizeClasses = {
  sm: 'text-[10px] px-2 py-0.5',
  md: 'text-xs px-3 py-1',
  lg: 'text-sm px-4 py-1.5',
};

export const RiskBadge = ({ level, size = 'md' }: RiskBadgeProps) => {
  const config = riskConfig[level];
  
  return (
    <span className={`risk-badge ${config.className} ${sizeClasses[size]}`}>
      {config.label}
    </span>
  );
};
