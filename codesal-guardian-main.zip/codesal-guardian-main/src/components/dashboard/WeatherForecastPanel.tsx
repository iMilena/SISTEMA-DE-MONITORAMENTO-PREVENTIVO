import { CloudRain, Droplets, Wind, Thermometer } from 'lucide-react';
import { weatherForecast, getRainIntensityColor } from '@/data/mockData';

export const WeatherForecastPanel = () => {
  const currentWeather = weatherForecast[0];

  return (
    <div className="absolute top-4 right-16 bg-card/95 backdrop-blur-sm rounded-lg border border-border/50 p-3 w-64 shadow-lg">
      <div className="flex items-center gap-2 mb-3">
        <CloudRain className="w-4 h-4 text-primary" />
        <span className="text-xs font-semibold text-foreground">Previsão do Tempo</span>
      </div>

      {/* Current conditions */}
      <div className="flex items-center justify-between mb-3 pb-3 border-b border-border/30">
        <div>
          <p className="text-2xl font-bold text-foreground">{currentWeather.temperature}°C</p>
          <p className="text-xs text-muted-foreground">{currentWeather.description}</p>
        </div>
        <div className="text-right space-y-1">
          <div className="flex items-center gap-1 text-xs">
            <Droplets className="w-3 h-3 text-primary" />
            <span className="text-muted-foreground">{currentWeather.humidity}%</span>
          </div>
          <div className="flex items-center gap-1 text-xs">
            <Wind className="w-3 h-3 text-muted-foreground" />
            <span className="text-muted-foreground">{currentWeather.windSpeed} km/h</span>
          </div>
        </div>
      </div>

      {/* Hourly forecast */}
      <div className="space-y-1.5">
        <p className="text-[10px] text-muted-foreground uppercase tracking-wide mb-2">Próximas Horas</p>
        {weatherForecast.slice(0, 6).map((forecast, index) => (
          <div 
            key={index}
            className="flex items-center justify-between text-xs py-1"
          >
            <span className="text-muted-foreground w-12">{forecast.hour}</span>
            <div className="flex items-center gap-1.5 flex-1">
              <div 
                className="w-2 h-2 rounded-full"
                style={{ backgroundColor: getRainIntensityColor(forecast.rainIntensity) }}
              />
              <div className="flex-1 bg-secondary/50 rounded-full h-1.5 overflow-hidden">
                <div 
                  className="h-full rounded-full transition-all"
                  style={{ 
                    width: `${forecast.rainProbability}%`,
                    backgroundColor: getRainIntensityColor(forecast.rainIntensity)
                  }}
                />
              </div>
            </div>
            <span className="text-foreground font-medium w-10 text-right">
              {forecast.rainProbability}%
            </span>
          </div>
        ))}
      </div>

      {/* Legend */}
      <div className="mt-3 pt-2 border-t border-border/30">
        <div className="flex items-center justify-between text-[10px]">
          <div className="flex items-center gap-1">
            <div className="w-2 h-2 rounded-full bg-risk-low" />
            <span className="text-muted-foreground">Leve</span>
          </div>
          <div className="flex items-center gap-1">
            <div className="w-2 h-2 rounded-full bg-risk-medium" />
            <span className="text-muted-foreground">Moderada</span>
          </div>
          <div className="flex items-center gap-1">
            <div className="w-2 h-2 rounded-full bg-risk-high" />
            <span className="text-muted-foreground">Forte</span>
          </div>
          <div className="flex items-center gap-1">
            <div className="w-2 h-2 rounded-full bg-risk-critical" />
            <span className="text-muted-foreground">Extrema</span>
          </div>
        </div>
      </div>
    </div>
  );
};