import { createContext, useContext, useState, ReactNode } from 'react';

interface MapboxContextType {
  token: string;
  setToken: (token: string) => void;
  isTokenValid: boolean;
}

const MapboxContext = createContext<MapboxContextType | undefined>(undefined);

export const MapboxProvider = ({ children }: { children: ReactNode }) => {
  const [token, setToken] = useState(() => {
    return localStorage.getItem('mapbox_token') || '';
  });

  const handleSetToken = (newToken: string) => {
    setToken(newToken);
    localStorage.setItem('mapbox_token', newToken);
  };

  const isTokenValid = token.startsWith('pk.');

  return (
    <MapboxContext.Provider value={{ token, setToken: handleSetToken, isTokenValid }}>
      {children}
    </MapboxContext.Provider>
  );
};

export const useMapbox = () => {
  const context = useContext(MapboxContext);
  if (!context) {
    throw new Error('useMapbox must be used within a MapboxProvider');
  }
  return context;
};
