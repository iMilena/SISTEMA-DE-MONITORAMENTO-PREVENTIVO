export type RiskLevel = 'critical' | 'high' | 'medium' | 'low';
export type CallStatus = 'new' | 'in_progress' | 'completed' | 'cancelled';

export interface Call {
  id: string;
  protocol: string;
  riskLevel: RiskLevel;
  aiConfidence: number;
  address: string;
  neighborhood: string;
  coordinates: { lat: number; lng: number };
  requesterName: string;
  requesterPhone: string;
  symptoms: string[];
  photoUrl: string;
  rainfall: number;
  createdAt: string;
  updatedAt: string;
  status: CallStatus;
  waitTime: number; // in minutes
  operator?: string;
  team?: string;
  observations: {
    text: string;
    author: string;
    timestamp: string;
  }[];
  areaClassification: string;
  soilType: string;
  slopeAngle: number;
  vegetation: string;
  drainage: string;
  nearbyPluviometers: { code: string; reading: number }[];
  aiRecommendation: string;
}

export interface HistoricalCall {
  protocol: string;
  date: string;
  riskLevel: RiskLevel;
  finalStatus: string;
  summary: string;
}

export const mockCalls: Call[] = [
  {
    id: '1',
    protocol: 'COD-2024-001234',
    riskLevel: 'critical',
    aiConfidence: 94,
    address: 'Rua das Flores, 123',
    neighborhood: 'Calabar',
    coordinates: { lat: -12.9914, lng: -38.5014 },
    requesterName: 'Maria Silva',
    requesterPhone: '+5571999887766',
    symptoms: ['Trincas em parede', 'Água barrenta', 'Estalos noturnos'],
    photoUrl: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400',
    rainfall: 45.2,
    createdAt: '2024-01-15T08:30:00',
    updatedAt: '2024-01-15T09:15:00',
    status: 'new',
    waitTime: 45,
    observations: [],
    areaClassification: 'R4 - Risco Muito Alto',
    soilType: 'Argiloso-siltoso, Alta Susceptibilidade a Erosão',
    slopeAngle: 35,
    vegetation: 'Desmatada',
    drainage: 'Precária',
    nearbyPluviometers: [
      { code: 'PLV-001', reading: 45.2 },
      { code: 'PLV-003', reading: 42.8 }
    ],
    aiRecommendation: 'URGENTE: Considerar evacuação preventiva imediata. Área com histórico de deslizamentos e chuva acima do limiar crítico.'
  },
  {
    id: '2',
    protocol: 'COD-2024-001235',
    riskLevel: 'high',
    aiConfidence: 87,
    address: 'Travessa São Jorge, 45',
    neighborhood: 'Engenho Velho de Brotas',
    coordinates: { lat: -12.9784, lng: -38.4892 },
    requesterName: 'João Santos',
    requesterPhone: '+5571988776655',
    symptoms: ['Rachaduras no solo', 'Árvore inclinada'],
    photoUrl: 'https://images.unsplash.com/photo-1513836279014-a89f7a76ae86?w=400',
    rainfall: 38.5,
    createdAt: '2024-01-15T07:45:00',
    updatedAt: '2024-01-15T08:30:00',
    status: 'in_progress',
    waitTime: 90,
    operator: 'Carlos Oliveira',
    team: 'Equipe Alpha',
    observations: [
      {
        text: 'Equipe Alpha a caminho. ETA 15 minutos.',
        author: 'Carlos Oliveira',
        timestamp: '2024-01-15T08:30:00'
      }
    ],
    areaClassification: 'R3 - Risco Alto',
    soilType: 'Arenoso com fragmentos rochosos',
    slopeAngle: 28,
    vegetation: 'Parcialmente vegetada',
    drainage: 'Regular',
    nearbyPluviometers: [
      { code: 'PLV-005', reading: 38.5 }
    ],
    aiRecommendation: 'Vistoria prioritária recomendada. Monitorar evolução das rachaduras.'
  },
  {
    id: '3',
    protocol: 'COD-2024-001236',
    riskLevel: 'medium',
    aiConfidence: 72,
    address: 'Ladeira do Abaeté, 78',
    neighborhood: 'Itapuã',
    coordinates: { lat: -12.9389, lng: -38.3614 },
    requesterName: 'Ana Costa',
    requesterPhone: '+5571977665544',
    symptoms: ['Infiltração no muro', 'Pequenas trincas'],
    photoUrl: 'https://images.unsplash.com/photo-1518173946687-a4c036bc4fb3?w=400',
    rainfall: 22.1,
    createdAt: '2024-01-15T09:00:00',
    updatedAt: '2024-01-15T09:00:00',
    status: 'new',
    waitTime: 30,
    observations: [],
    areaClassification: 'R2 - Risco Médio',
    soilType: 'Areia fina',
    slopeAngle: 15,
    vegetation: 'Vegetação densa',
    drainage: 'Adequada',
    nearbyPluviometers: [
      { code: 'PLV-008', reading: 22.1 }
    ],
    aiRecommendation: 'Agendar vistoria técnica. Baixa probabilidade de evolução rápida.'
  },
  {
    id: '4',
    protocol: 'COD-2024-001237',
    riskLevel: 'critical',
    aiConfidence: 91,
    address: 'Rua da Encosta, 200',
    neighborhood: 'Bom Juá',
    coordinates: { lat: -12.9456, lng: -38.4234 },
    requesterName: 'Pedro Almeida',
    requesterPhone: '+5571966554433',
    symptoms: ['Deslizamento parcial', 'Casa cedendo', 'Moradores assustados'],
    photoUrl: 'https://images.unsplash.com/photo-1509316975850-ff9c5deb0cd9?w=400',
    rainfall: 52.3,
    createdAt: '2024-01-15T06:15:00',
    updatedAt: '2024-01-15T09:20:00',
    status: 'in_progress',
    waitTime: 180,
    operator: 'Ana Souza',
    team: 'Equipe Beta',
    observations: [
      {
        text: 'Situação crítica confirmada. Evacuação em andamento.',
        author: 'Ana Souza',
        timestamp: '2024-01-15T08:00:00'
      },
      {
        text: '3 famílias evacuadas. Aguardando engenheiro geotécnico.',
        author: 'Ana Souza',
        timestamp: '2024-01-15T09:20:00'
      }
    ],
    areaClassification: 'R4 - Risco Muito Alto',
    soilType: 'Argila expansiva',
    slopeAngle: 42,
    vegetation: 'Desmatada',
    drainage: 'Inexistente',
    nearbyPluviometers: [
      { code: 'PLV-002', reading: 52.3 },
      { code: 'PLV-004', reading: 48.9 }
    ],
    aiRecommendation: 'EVACUAÇÃO IMEDIATA. Risco iminente de colapso estrutural.'
  },
  {
    id: '5',
    protocol: 'COD-2024-001238',
    riskLevel: 'low',
    aiConfidence: 65,
    address: 'Av. Oceânica, 1500',
    neighborhood: 'Barra',
    coordinates: { lat: -13.0089, lng: -38.5234 },
    requesterName: 'Lucia Ferreira',
    requesterPhone: '+5571955443322',
    symptoms: ['Pequena erosão no jardim'],
    photoUrl: 'https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=400',
    rainfall: 12.5,
    createdAt: '2024-01-15T10:00:00',
    updatedAt: '2024-01-15T10:00:00',
    status: 'new',
    waitTime: 15,
    observations: [],
    areaClassification: 'R1 - Risco Baixo',
    soilType: 'Areia compactada',
    slopeAngle: 5,
    vegetation: 'Jardim bem mantido',
    drainage: 'Excelente',
    nearbyPluviometers: [
      { code: 'PLV-010', reading: 12.5 }
    ],
    aiRecommendation: 'Baixa prioridade. Orientar morador sobre manutenção preventiva.'
  },
  {
    id: '6',
    protocol: 'COD-2024-001239',
    riskLevel: 'high',
    aiConfidence: 85,
    address: 'Rua do Morro, 89',
    neighborhood: 'Nordeste de Amaralina',
    coordinates: { lat: -12.9956, lng: -38.4567 },
    requesterName: 'Francisco Lima',
    requesterPhone: '+5571944332211',
    symptoms: ['Muro de arrimo rachado', 'Vazamento de água'],
    photoUrl: 'https://images.unsplash.com/photo-1504893524553-b855bce32c67?w=400',
    rainfall: 35.8,
    createdAt: '2024-01-15T08:00:00',
    updatedAt: '2024-01-15T08:45:00',
    status: 'new',
    waitTime: 60,
    observations: [],
    areaClassification: 'R3 - Risco Alto',
    soilType: 'Solo misto com entulho',
    slopeAngle: 32,
    vegetation: 'Escassa',
    drainage: 'Comprometida',
    nearbyPluviometers: [
      { code: 'PLV-006', reading: 35.8 }
    ],
    aiRecommendation: 'Atenção: Muro de arrimo pode colapsar. Verificar estrutura com urgência.'
  }
];

export const historicalCalls: Record<string, HistoricalCall[]> = {
  'Calabar': [
    { protocol: 'COD-2023-008456', date: '2023-12-10', riskLevel: 'critical', finalStatus: 'Evacuação realizada', summary: 'Deslizamento em encosta, 2 casas atingidas' },
    { protocol: 'COD-2023-007823', date: '2023-11-25', riskLevel: 'high', finalStatus: 'Obra emergencial', summary: 'Contenção de talude' },
    { protocol: 'COD-2023-006234', date: '2023-10-15', riskLevel: 'medium', finalStatus: 'Monitoramento', summary: 'Trincas em residência' },
  ],
  'Bom Juá': [
    { protocol: 'COD-2023-009012', date: '2023-12-20', riskLevel: 'critical', finalStatus: 'Demolição preventiva', summary: 'Estrutura condenada' },
    { protocol: 'COD-2023-008001', date: '2023-11-30', riskLevel: 'high', finalStatus: 'Evacuação realizada', summary: 'Risco de desabamento' },
  ],
  'Engenho Velho de Brotas': [
    { protocol: 'COD-2023-007500', date: '2023-11-10', riskLevel: 'medium', finalStatus: 'Resolvido', summary: 'Drenagem reparada' },
  ]
};

export const teams = [
  'Equipe Alpha',
  'Equipe Beta',
  'Equipe Gamma',
  'Equipe Delta',
  'Equipe Omega'
];

export const operators = [
  'Carlos Oliveira',
  'Ana Souza',
  'Roberto Santos',
  'Patricia Lima',
  'Fernando Costa'
];

export const kpiData = {
  activePriorities: 4,
  dailyCalls: 23,
  avgResponseTime: 42, // minutes
  monthlyCompleted: 156,
  totalOpen: 18
};

// Pluviômetros CEMADEN - Salvador
export interface Pluviometer {
  id: string;
  code: string;
  name: string;
  coordinates: { lat: number; lng: number };
  reading: number; // mm/h
  lastUpdate: string;
  status: 'normal' | 'alert' | 'critical' | 'offline';
}

export const pluviometers: Pluviometer[] = [
  { id: 'plv-001', code: 'PLV-001', name: 'Calabar', coordinates: { lat: -12.9914, lng: -38.5014 }, reading: 45.2, lastUpdate: '2024-01-15T09:30:00', status: 'critical' },
  { id: 'plv-002', code: 'PLV-002', name: 'Bom Juá', coordinates: { lat: -12.9456, lng: -38.4234 }, reading: 52.3, lastUpdate: '2024-01-15T09:30:00', status: 'critical' },
  { id: 'plv-003', code: 'PLV-003', name: 'Calabar Sul', coordinates: { lat: -12.9954, lng: -38.5054 }, reading: 42.8, lastUpdate: '2024-01-15T09:30:00', status: 'alert' },
  { id: 'plv-004', code: 'PLV-004', name: 'Bom Juá Norte', coordinates: { lat: -12.9406, lng: -38.4284 }, reading: 48.9, lastUpdate: '2024-01-15T09:30:00', status: 'critical' },
  { id: 'plv-005', code: 'PLV-005', name: 'Engenho Velho', coordinates: { lat: -12.9784, lng: -38.4892 }, reading: 38.5, lastUpdate: '2024-01-15T09:30:00', status: 'alert' },
  { id: 'plv-006', code: 'PLV-006', name: 'Nordeste Amaralina', coordinates: { lat: -12.9956, lng: -38.4567 }, reading: 35.8, lastUpdate: '2024-01-15T09:30:00', status: 'alert' },
  { id: 'plv-007', code: 'PLV-007', name: 'Pituba', coordinates: { lat: -12.9889, lng: -38.4456 }, reading: 18.2, lastUpdate: '2024-01-15T09:30:00', status: 'normal' },
  { id: 'plv-008', code: 'PLV-008', name: 'Itapuã', coordinates: { lat: -12.9389, lng: -38.3614 }, reading: 22.1, lastUpdate: '2024-01-15T09:30:00', status: 'normal' },
  { id: 'plv-009', code: 'PLV-009', name: 'Piatã', coordinates: { lat: -12.9489, lng: -38.3814 }, reading: 15.5, lastUpdate: '2024-01-15T09:30:00', status: 'normal' },
  { id: 'plv-010', code: 'PLV-010', name: 'Barra', coordinates: { lat: -13.0089, lng: -38.5234 }, reading: 12.5, lastUpdate: '2024-01-15T09:30:00', status: 'normal' },
  { id: 'plv-011', code: 'PLV-011', name: 'Rio Vermelho', coordinates: { lat: -13.0156, lng: -38.4789 }, reading: 28.3, lastUpdate: '2024-01-15T09:30:00', status: 'normal' },
  { id: 'plv-012', code: 'PLV-012', name: 'Liberdade', coordinates: { lat: -12.9567, lng: -38.4956 }, reading: 32.1, lastUpdate: '2024-01-15T09:30:00', status: 'alert' },
];

// Previsão do Tempo - Salvador
export interface WeatherForecast {
  hour: string;
  temperature: number;
  rainProbability: number;
  rainIntensity: 'none' | 'light' | 'moderate' | 'heavy' | 'extreme';
  humidity: number;
  windSpeed: number;
  description: string;
}

export const weatherForecast: WeatherForecast[] = [
  { hour: '10:00', temperature: 26, rainProbability: 85, rainIntensity: 'heavy', humidity: 92, windSpeed: 15, description: 'Chuva forte' },
  { hour: '11:00', temperature: 25, rainProbability: 90, rainIntensity: 'heavy', humidity: 95, windSpeed: 18, description: 'Chuva forte' },
  { hour: '12:00', temperature: 24, rainProbability: 95, rainIntensity: 'extreme', humidity: 98, windSpeed: 22, description: 'Chuva muito forte' },
  { hour: '13:00', temperature: 24, rainProbability: 80, rainIntensity: 'heavy', humidity: 94, windSpeed: 20, description: 'Chuva forte' },
  { hour: '14:00', temperature: 25, rainProbability: 60, rainIntensity: 'moderate', humidity: 88, windSpeed: 16, description: 'Chuva moderada' },
  { hour: '15:00', temperature: 26, rainProbability: 45, rainIntensity: 'light', humidity: 82, windSpeed: 12, description: 'Chuva leve' },
  { hour: '16:00', temperature: 27, rainProbability: 30, rainIntensity: 'light', humidity: 78, windSpeed: 10, description: 'Possível chuva' },
  { hour: '17:00', temperature: 27, rainProbability: 20, rainIntensity: 'none', humidity: 74, windSpeed: 8, description: 'Nublado' },
  { hour: '18:00', temperature: 26, rainProbability: 15, rainIntensity: 'none', humidity: 72, windSpeed: 8, description: 'Parcialmente nublado' },
];

// Helper functions
export const getPluviometerColor = (reading: number): string => {
  if (reading >= 50) return '#ef4444'; // critical - red
  if (reading >= 35) return '#f97316'; // alert - orange
  if (reading >= 20) return '#eab308'; // moderate - yellow
  return '#22c55e'; // normal - green
};

export const getRainIntensityColor = (intensity: WeatherForecast['rainIntensity']): string => {
  switch (intensity) {
    case 'extreme': return '#ef4444';
    case 'heavy': return '#f97316';
    case 'moderate': return '#eab308';
    case 'light': return '#22c55e';
    default: return '#6b7280';
  }
};
