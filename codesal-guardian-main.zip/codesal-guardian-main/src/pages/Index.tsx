import { useState } from 'react';
import { Header } from '@/components/dashboard/Header';
import { KPICards } from '@/components/dashboard/KPICards';
import { PriorityList } from '@/components/dashboard/PriorityList';
import { MapView } from '@/components/dashboard/MapView';
import { CallDetailsPanel } from '@/components/dashboard/CallDetailsPanel';
import { mockCalls, Call } from '@/data/mockData';

const Index = () => {
  const [selectedCall, setSelectedCall] = useState<Call | null>(null);

  return (
    <div className="h-screen flex flex-col bg-background overflow-hidden">
      <Header />
      <KPICards />
      <div className="flex-1 flex overflow-hidden">
        <PriorityList 
          calls={mockCalls}
          selectedCall={selectedCall}
          onSelectCall={setSelectedCall}
        />
        <MapView 
          calls={mockCalls}
          selectedCall={selectedCall}
          onSelectCall={setSelectedCall}
        />
        <CallDetailsPanel call={selectedCall} />
      </div>
    </div>
  );
};

export default Index;
