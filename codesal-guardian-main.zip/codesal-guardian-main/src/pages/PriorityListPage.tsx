import { useState } from 'react';
import { Header } from '@/components/dashboard/Header';
import { mockCalls, Call, RiskLevel } from '@/data/mockData';
import { RiskBadge } from '@/components/dashboard/RiskBadge';
import { Search, Filter, Clock, Droplets, MapPin, Eye, Phone, ChevronDown, ChevronUp } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';

const PriorityListPage = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [riskFilter, setRiskFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [sortField, setSortField] = useState<'riskLevel' | 'waitTime' | 'rainfall'>('riskLevel');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc');
  const [expandedRow, setExpandedRow] = useState<string | null>(null);

  const filteredCalls = mockCalls.filter(call => {
    const matchesSearch = 
      call.protocol.toLowerCase().includes(searchTerm.toLowerCase()) ||
      call.neighborhood.toLowerCase().includes(searchTerm.toLowerCase()) ||
      call.address.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesRisk = riskFilter === 'all' || call.riskLevel === riskFilter;
    const matchesStatus = statusFilter === 'all' || call.status === statusFilter;

    return matchesSearch && matchesRisk && matchesStatus;
  });

  const sortedCalls = [...filteredCalls].sort((a, b) => {
    const riskOrder: Record<RiskLevel, number> = { critical: 0, high: 1, medium: 2, low: 3 };
    
    let comparison = 0;
    switch (sortField) {
      case 'riskLevel':
        comparison = riskOrder[a.riskLevel] - riskOrder[b.riskLevel];
        break;
      case 'waitTime':
        comparison = a.waitTime - b.waitTime;
        break;
      case 'rainfall':
        comparison = a.rainfall - b.rainfall;
        break;
    }
    
    return sortDirection === 'desc' ? -comparison : comparison;
  });

  const formatWaitTime = (minutes: number) => {
    if (minutes < 60) return `${minutes} min`;
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return `${hours}h ${mins}m`;
  };

  const getStatusLabel = (status: string) => {
    const labels: Record<string, string> = {
      new: 'Novo',
      in_progress: 'Em Vistoria',
      completed: 'Concluído',
      cancelled: 'Cancelado'
    };
    return labels[status] || status;
  };

  const toggleSort = (field: typeof sortField) => {
    if (sortField === field) {
      setSortDirection(prev => prev === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('desc');
    }
  };

  const SortIcon = ({ field }: { field: typeof sortField }) => {
    if (sortField !== field) return null;
    return sortDirection === 'desc' ? 
      <ChevronDown className="w-4 h-4 inline ml-1" /> : 
      <ChevronUp className="w-4 h-4 inline ml-1" />;
  };

  return (
    <div className="h-screen flex flex-col bg-background overflow-hidden">
      <Header />
      
      <div className="flex-1 p-6 overflow-hidden flex flex-col">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Lista de Prioridades</h1>
            <p className="text-sm text-muted-foreground">Gerenciamento completo de chamados</p>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-sm text-muted-foreground">
              {sortedCalls.length} chamados encontrados
            </span>
          </div>
        </div>

        {/* Filters */}
        <div className="flex items-center gap-4 mb-6 p-4 bg-card/50 rounded-xl border border-border/50">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Buscar protocolo, bairro, endereço..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-9 bg-secondary/50 border-border/50"
            />
          </div>
          <Select value={riskFilter} onValueChange={setRiskFilter}>
            <SelectTrigger className="w-48 bg-secondary/50 border-border/50">
              <SelectValue placeholder="Nível de Risco" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos os Riscos</SelectItem>
              <SelectItem value="critical">Crítico</SelectItem>
              <SelectItem value="high">Alto</SelectItem>
              <SelectItem value="medium">Médio</SelectItem>
              <SelectItem value="low">Baixo</SelectItem>
            </SelectContent>
          </Select>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-48 bg-secondary/50 border-border/50">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos os Status</SelectItem>
              <SelectItem value="new">Novo</SelectItem>
              <SelectItem value="in_progress">Em Vistoria</SelectItem>
              <SelectItem value="completed">Concluído</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Table */}
        <div className="flex-1 bg-card/50 rounded-xl border border-border/50 overflow-hidden">
          <div className="overflow-auto h-full">
            <Table>
              <TableHeader className="sticky top-0 bg-card">
                <TableRow className="border-border/50 hover:bg-transparent">
                  <TableHead 
                    className="cursor-pointer hover:text-foreground"
                    onClick={() => toggleSort('riskLevel')}
                  >
                    Risco <SortIcon field="riskLevel" />
                  </TableHead>
                  <TableHead>Protocolo</TableHead>
                  <TableHead>Local</TableHead>
                  <TableHead 
                    className="cursor-pointer hover:text-foreground"
                    onClick={() => toggleSort('rainfall')}
                  >
                    Chuva <SortIcon field="rainfall" />
                  </TableHead>
                  <TableHead 
                    className="cursor-pointer hover:text-foreground"
                    onClick={() => toggleSort('waitTime')}
                  >
                    Espera <SortIcon field="waitTime" />
                  </TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Operador</TableHead>
                  <TableHead className="text-right">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {sortedCalls.map((call) => (
                  <>
                    <TableRow 
                      key={call.id}
                      className="border-border/50 cursor-pointer hover:bg-secondary/30"
                      onClick={() => setExpandedRow(expandedRow === call.id ? null : call.id)}
                    >
                      <TableCell>
                        <RiskBadge level={call.riskLevel} size="sm" />
                      </TableCell>
                      <TableCell className="font-mono text-sm">{call.protocol}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1.5">
                          <MapPin className="w-3.5 h-3.5 text-muted-foreground" />
                          <span>{call.neighborhood}</span>
                        </div>
                        <p className="text-xs text-muted-foreground truncate max-w-[200px]">
                          {call.address}
                        </p>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1.5">
                          <Droplets className="w-3.5 h-3.5 text-primary" />
                          <span>{call.rainfall} mm/h</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1.5">
                          <Clock className="w-3.5 h-3.5 text-muted-foreground" />
                          <span>{formatWaitTime(call.waitTime)}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <span className={`px-2 py-1 rounded text-xs font-medium ${
                          call.status === 'new' 
                            ? 'bg-status-new/20 text-status-new' 
                            : call.status === 'in_progress'
                            ? 'bg-status-progress/20 text-status-progress'
                            : 'bg-status-completed/20 text-status-completed'
                        }`}>
                          {getStatusLabel(call.status)}
                        </span>
                      </TableCell>
                      <TableCell>
                        <span className="text-sm">{call.operator || '-'}</span>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-2">
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <Eye className="w-4 h-4" />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <Phone className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                    {expandedRow === call.id && (
                      <TableRow className="bg-secondary/20 border-border/50">
                        <TableCell colSpan={8}>
                          <div className="p-4 grid grid-cols-3 gap-6">
                            <div>
                              <h4 className="text-sm font-semibold text-foreground mb-2">Solicitante</h4>
                              <p className="text-sm">{call.requesterName}</p>
                              <p className="text-sm text-muted-foreground">{call.requesterPhone}</p>
                            </div>
                            <div>
                              <h4 className="text-sm font-semibold text-foreground mb-2">Sintomas Reportados</h4>
                              <div className="flex flex-wrap gap-1">
                                {call.symptoms.map((symptom, i) => (
                                  <span key={i} className="px-2 py-0.5 bg-primary/10 text-primary text-xs rounded">
                                    {symptom}
                                  </span>
                                ))}
                              </div>
                            </div>
                            <div>
                              <h4 className="text-sm font-semibold text-foreground mb-2">Recomendação IA</h4>
                              <p className="text-sm text-muted-foreground">{call.aiRecommendation}</p>
                            </div>
                          </div>
                        </TableCell>
                      </TableRow>
                    )}
                  </>
                ))}
              </TableBody>
            </Table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PriorityListPage;