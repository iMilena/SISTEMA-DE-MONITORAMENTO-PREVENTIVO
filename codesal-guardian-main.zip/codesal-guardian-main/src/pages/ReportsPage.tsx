import { Header } from '@/components/dashboard/Header';
import { mockCalls, pluviometers, weatherForecast, kpiData } from '@/data/mockData';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, LineChart, Line, AreaChart, Area, Legend
} from 'recharts';
import { TrendingUp, Users, Clock, AlertTriangle, CloudRain, MapPin } from 'lucide-react';

const ReportsPage = () => {
  // Data for charts
  const callsByNeighborhood = [
    { name: 'Calabar', total: 45, critical: 12 },
    { name: 'Bom Juá', total: 38, critical: 15 },
    { name: 'Eng. Velho', total: 28, critical: 5 },
    { name: 'Nordeste Amaralina', total: 22, critical: 8 },
    { name: 'Itapuã', total: 18, critical: 2 },
    { name: 'Barra', total: 12, critical: 1 },
  ];

  const callsByRisk = [
    { name: 'Crítico', value: 43, color: '#ef4444' },
    { name: 'Alto', value: 67, color: '#f97316' },
    { name: 'Médio', value: 89, color: '#eab308' },
    { name: 'Baixo', value: 45, color: '#22c55e' },
  ];

  const responseTimeByDay = [
    { day: 'Seg', avgTime: 35, calls: 28 },
    { day: 'Ter', avgTime: 42, calls: 32 },
    { day: 'Qua', avgTime: 38, calls: 25 },
    { day: 'Qui', avgTime: 45, calls: 35 },
    { day: 'Sex', avgTime: 40, calls: 30 },
    { day: 'Sáb', avgTime: 55, calls: 18 },
    { day: 'Dom', avgTime: 60, calls: 12 },
  ];

  const rainfallVsCalls = [
    { hour: '06:00', rainfall: 12, calls: 2 },
    { hour: '08:00', rainfall: 25, calls: 5 },
    { hour: '10:00', rainfall: 45, calls: 12 },
    { hour: '12:00', rainfall: 55, calls: 18 },
    { hour: '14:00', rainfall: 40, calls: 15 },
    { hour: '16:00', rainfall: 28, calls: 8 },
    { hour: '18:00', rainfall: 15, calls: 4 },
  ];

  const teamPerformance = [
    { team: 'Alpha', resolved: 45, avgTime: 32 },
    { team: 'Beta', resolved: 52, avgTime: 28 },
    { team: 'Gamma', resolved: 38, avgTime: 35 },
    { team: 'Delta', resolved: 41, avgTime: 30 },
    { team: 'Omega', resolved: 35, avgTime: 38 },
  ];

  return (
    <div className="h-screen flex flex-col bg-background overflow-hidden">
      <Header />
      
      <div className="flex-1 p-6 overflow-auto">
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-foreground">Relatórios e Análises</h1>
          <p className="text-sm text-muted-foreground">Visão analítica das operações CODESAL</p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-4 gap-4 mb-6">
          <Card className="bg-card/50 border-border/50">
            <CardContent className="pt-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total Mensal</p>
                  <p className="text-2xl font-bold text-foreground">244</p>
                </div>
                <div className="p-3 bg-primary/10 rounded-lg">
                  <TrendingUp className="w-6 h-6 text-primary" />
                </div>
              </div>
              <p className="text-xs text-risk-high mt-2">+12% vs mês anterior</p>
            </CardContent>
          </Card>
          
          <Card className="bg-card/50 border-border/50">
            <CardContent className="pt-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Taxa Resolução</p>
                  <p className="text-2xl font-bold text-foreground">87%</p>
                </div>
                <div className="p-3 bg-risk-low/10 rounded-lg">
                  <Users className="w-6 h-6 text-risk-low" />
                </div>
              </div>
              <p className="text-xs text-risk-low mt-2">+5% vs mês anterior</p>
            </CardContent>
          </Card>
          
          <Card className="bg-card/50 border-border/50">
            <CardContent className="pt-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Tempo Médio</p>
                  <p className="text-2xl font-bold text-foreground">{kpiData.avgResponseTime}min</p>
                </div>
                <div className="p-3 bg-status-progress/10 rounded-lg">
                  <Clock className="w-6 h-6 text-status-progress" />
                </div>
              </div>
              <p className="text-xs text-risk-low mt-2">-8min vs mês anterior</p>
            </CardContent>
          </Card>
          
          <Card className="bg-card/50 border-border/50">
            <CardContent className="pt-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Críticos Ativos</p>
                  <p className="text-2xl font-bold text-foreground">{kpiData.activePriorities}</p>
                </div>
                <div className="p-3 bg-risk-critical/10 rounded-lg">
                  <AlertTriangle className="w-6 h-6 text-risk-critical" />
                </div>
              </div>
              <p className="text-xs text-muted-foreground mt-2">Requer atenção imediata</p>
            </CardContent>
          </Card>
        </div>

        {/* Charts Row 1 */}
        <div className="grid grid-cols-2 gap-6 mb-6">
          <Card className="bg-card/50 border-border/50">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <MapPin className="w-4 h-4 text-primary" />
                Chamados por Bairro
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={250}>
                <BarChart data={callsByNeighborhood}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.3} />
                  <XAxis dataKey="name" tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 11 }} />
                  <YAxis tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 11 }} />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'hsl(var(--card))', 
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '8px'
                    }}
                  />
                  <Bar dataKey="total" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} name="Total" />
                  <Bar dataKey="critical" fill="#ef4444" radius={[4, 4, 0, 0]} name="Críticos" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card className="bg-card/50 border-border/50">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-risk-high" />
                Distribuição por Risco
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={250}>
                <PieChart>
                  <Pie
                    data={callsByRisk}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={90}
                    paddingAngle={2}
                    dataKey="value"
                  >
                    {callsByRisk.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'hsl(var(--card))', 
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '8px'
                    }}
                  />
                  <Legend 
                    verticalAlign="middle" 
                    align="right"
                    layout="vertical"
                    formatter={(value) => <span style={{ color: 'hsl(var(--foreground))' }}>{value}</span>}
                  />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        {/* Charts Row 2 */}
        <div className="grid grid-cols-2 gap-6 mb-6">
          <Card className="bg-card/50 border-border/50">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <Clock className="w-4 h-4 text-status-progress" />
                Tempo de Resposta por Dia
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={250}>
                <LineChart data={responseTimeByDay}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.3} />
                  <XAxis dataKey="day" tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 11 }} />
                  <YAxis tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 11 }} />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'hsl(var(--card))', 
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '8px'
                    }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="avgTime" 
                    stroke="hsl(var(--primary))" 
                    strokeWidth={2}
                    dot={{ fill: 'hsl(var(--primary))' }}
                    name="Tempo Médio (min)"
                  />
                  <Line 
                    type="monotone" 
                    dataKey="calls" 
                    stroke="#f97316" 
                    strokeWidth={2}
                    dot={{ fill: '#f97316' }}
                    name="Chamados"
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card className="bg-card/50 border-border/50">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <CloudRain className="w-4 h-4 text-primary" />
                Chuva vs Chamados (Hoje)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={250}>
                <AreaChart data={rainfallVsCalls}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.3} />
                  <XAxis dataKey="hour" tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 11 }} />
                  <YAxis tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 11 }} />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'hsl(var(--card))', 
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '8px'
                    }}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="rainfall" 
                    stackId="1"
                    stroke="hsl(var(--primary))" 
                    fill="hsl(var(--primary))"
                    fillOpacity={0.3}
                    name="Chuva (mm/h)"
                  />
                  <Area 
                    type="monotone" 
                    dataKey="calls" 
                    stackId="2"
                    stroke="#ef4444" 
                    fill="#ef4444"
                    fillOpacity={0.3}
                    name="Chamados"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        {/* Team Performance */}
        <Card className="bg-card/50 border-border/50">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Users className="w-4 h-4 text-risk-low" />
              Desempenho das Equipes (Mês)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={teamPerformance} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.3} />
                <XAxis type="number" tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 11 }} />
                <YAxis dataKey="team" type="category" tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 11 }} width={60} />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'hsl(var(--card))', 
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '8px'
                  }}
                />
                <Bar dataKey="resolved" fill="#22c55e" radius={[0, 4, 4, 0]} name="Resolvidos" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default ReportsPage;