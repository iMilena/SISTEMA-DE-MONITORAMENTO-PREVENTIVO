import { useState } from 'react';
import { Header } from '@/components/dashboard/Header';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import { 
  User, Bell, Shield, Map, Palette, Volume2, 
  Save, RefreshCw, Key, Mail, Phone, Building
} from 'lucide-react';
import { useMapbox } from '@/contexts/MapboxContext';

const SettingsPage = () => {
  const { toast } = useToast();
  const { token, setToken } = useMapbox();
  
  // Profile settings
  const [profile, setProfile] = useState({
    name: 'Operador CODESAL',
    email: 'operador@codesal.salvador.ba.gov.br',
    phone: '+55 71 99999-9999',
    department: 'Central de Operações',
    role: 'Operador',
  });

  // Notification settings
  const [notifications, setNotifications] = useState({
    criticalAlerts: true,
    highRiskAlerts: true,
    newCalls: true,
    teamUpdates: true,
    soundEnabled: true,
    desktopNotifications: true,
    emailNotifications: false,
  });

  // Map settings
  const [mapSettings, setMapSettings] = useState({
    mapboxToken: token,
    defaultZoom: '11.5',
    showHeatmap: true,
    showRiskAreas: true,
    showPluviometers: true,
    autoRefresh: true,
    refreshInterval: '30',
  });

  // Theme settings
  const [theme, setTheme] = useState({
    mode: 'dark',
    accentColor: 'cyan',
    fontSize: 'medium',
  });

  const handleSaveProfile = () => {
    toast({
      title: 'Perfil atualizado',
      description: 'Suas informações de perfil foram salvas com sucesso.',
    });
  };

  const handleSaveNotifications = () => {
    toast({
      title: 'Notificações atualizadas',
      description: 'Suas preferências de notificação foram salvas.',
    });
  };

  const handleSaveMapSettings = () => {
    if (mapSettings.mapboxToken) {
      setToken(mapSettings.mapboxToken);
    }
    toast({
      title: 'Configurações do mapa salvas',
      description: 'As configurações do mapa foram atualizadas.',
    });
  };

  const handleSaveTheme = () => {
    toast({
      title: 'Tema atualizado',
      description: 'Suas preferências de tema foram aplicadas.',
    });
  };

  return (
    <div className="h-screen flex flex-col bg-background overflow-hidden">
      <Header />
      
      <div className="flex-1 p-6 overflow-auto">
        <div className="max-w-4xl mx-auto">
          <div className="mb-6">
            <h1 className="text-2xl font-bold text-foreground">Configurações</h1>
            <p className="text-sm text-muted-foreground">Gerencie suas preferências e configurações do sistema</p>
          </div>

          <Tabs defaultValue="profile" className="space-y-6">
            <TabsList className="bg-card/50 border border-border/50">
              <TabsTrigger value="profile" className="gap-2">
                <User className="w-4 h-4" />
                Perfil
              </TabsTrigger>
              <TabsTrigger value="notifications" className="gap-2">
                <Bell className="w-4 h-4" />
                Notificações
              </TabsTrigger>
              <TabsTrigger value="map" className="gap-2">
                <Map className="w-4 h-4" />
                Mapa
              </TabsTrigger>
              <TabsTrigger value="appearance" className="gap-2">
                <Palette className="w-4 h-4" />
                Aparência
              </TabsTrigger>
            </TabsList>

            {/* Profile Tab */}
            <TabsContent value="profile">
              <Card className="bg-card/50 border-border/50">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <User className="w-5 h-5 text-primary" />
                    Informações do Perfil
                  </CardTitle>
                  <CardDescription>
                    Atualize suas informações pessoais e de contato
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="name">Nome Completo</Label>
                      <div className="relative">
                        <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                        <Input
                          id="name"
                          value={profile.name}
                          onChange={e => setProfile({ ...profile, name: e.target.value })}
                          className="pl-9 bg-secondary/50 border-border/50"
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="email">E-mail</Label>
                      <div className="relative">
                        <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                        <Input
                          id="email"
                          type="email"
                          value={profile.email}
                          onChange={e => setProfile({ ...profile, email: e.target.value })}
                          className="pl-9 bg-secondary/50 border-border/50"
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="phone">Telefone</Label>
                      <div className="relative">
                        <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                        <Input
                          id="phone"
                          value={profile.phone}
                          onChange={e => setProfile({ ...profile, phone: e.target.value })}
                          className="pl-9 bg-secondary/50 border-border/50"
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="department">Departamento</Label>
                      <div className="relative">
                        <Building className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                        <Input
                          id="department"
                          value={profile.department}
                          onChange={e => setProfile({ ...profile, department: e.target.value })}
                          className="pl-9 bg-secondary/50 border-border/50"
                        />
                      </div>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="role">Função</Label>
                    <Select
                      value={profile.role}
                      onValueChange={value => setProfile({ ...profile, role: value })}
                    >
                      <SelectTrigger className="bg-secondary/50 border-border/50">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Operador">Operador</SelectItem>
                        <SelectItem value="Supervisor">Supervisor</SelectItem>
                        <SelectItem value="Coordenador">Coordenador</SelectItem>
                        <SelectItem value="Administrador">Administrador</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <Button onClick={handleSaveProfile} className="gap-2">
                    <Save className="w-4 h-4" />
                    Salvar Perfil
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Notifications Tab */}
            <TabsContent value="notifications">
              <Card className="bg-card/50 border-border/50">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Bell className="w-5 h-5 text-primary" />
                    Preferências de Notificação
                  </CardTitle>
                  <CardDescription>
                    Configure quais alertas você deseja receber
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-4">
                    <h4 className="text-sm font-medium text-foreground flex items-center gap-2">
                      <Shield className="w-4 h-4 text-risk-critical" />
                      Alertas de Risco
                    </h4>
                    <div className="space-y-3 pl-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <Label className="font-normal">Alertas Críticos</Label>
                          <p className="text-xs text-muted-foreground">
                            Receber notificações de situações críticas imediatamente
                          </p>
                        </div>
                        <Switch
                          checked={notifications.criticalAlerts}
                          onCheckedChange={checked =>
                            setNotifications({ ...notifications, criticalAlerts: checked })
                          }
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <div>
                          <Label className="font-normal">Alertas de Alto Risco</Label>
                          <p className="text-xs text-muted-foreground">
                            Notificar quando chamados de alto risco forem criados
                          </p>
                        </div>
                        <Switch
                          checked={notifications.highRiskAlerts}
                          onCheckedChange={checked =>
                            setNotifications({ ...notifications, highRiskAlerts: checked })
                          }
                        />
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h4 className="text-sm font-medium text-foreground">Operações</h4>
                    <div className="space-y-3 pl-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <Label className="font-normal">Novos Chamados</Label>
                          <p className="text-xs text-muted-foreground">
                            Notificar quando novos chamados forem recebidos
                          </p>
                        </div>
                        <Switch
                          checked={notifications.newCalls}
                          onCheckedChange={checked =>
                            setNotifications({ ...notifications, newCalls: checked })
                          }
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <div>
                          <Label className="font-normal">Atualizações de Equipe</Label>
                          <p className="text-xs text-muted-foreground">
                            Receber atualizações sobre designações e status
                          </p>
                        </div>
                        <Switch
                          checked={notifications.teamUpdates}
                          onCheckedChange={checked =>
                            setNotifications({ ...notifications, teamUpdates: checked })
                          }
                        />
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h4 className="text-sm font-medium text-foreground flex items-center gap-2">
                      <Volume2 className="w-4 h-4" />
                      Canais de Notificação
                    </h4>
                    <div className="space-y-3 pl-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <Label className="font-normal">Alerta Sonoro</Label>
                          <p className="text-xs text-muted-foreground">
                            Reproduzir som para alertas críticos
                          </p>
                        </div>
                        <Switch
                          checked={notifications.soundEnabled}
                          onCheckedChange={checked =>
                            setNotifications({ ...notifications, soundEnabled: checked })
                          }
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <div>
                          <Label className="font-normal">Notificações Desktop</Label>
                          <p className="text-xs text-muted-foreground">
                            Mostrar notificações do sistema operacional
                          </p>
                        </div>
                        <Switch
                          checked={notifications.desktopNotifications}
                          onCheckedChange={checked =>
                            setNotifications({ ...notifications, desktopNotifications: checked })
                          }
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <div>
                          <Label className="font-normal">Notificações por E-mail</Label>
                          <p className="text-xs text-muted-foreground">
                            Enviar resumo de alertas por e-mail
                          </p>
                        </div>
                        <Switch
                          checked={notifications.emailNotifications}
                          onCheckedChange={checked =>
                            setNotifications({ ...notifications, emailNotifications: checked })
                          }
                        />
                      </div>
                    </div>
                  </div>

                  <Button onClick={handleSaveNotifications} className="gap-2">
                    <Save className="w-4 h-4" />
                    Salvar Preferências
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Map Tab */}
            <TabsContent value="map">
              <Card className="bg-card/50 border-border/50">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Map className="w-5 h-5 text-primary" />
                    Configurações do Mapa
                  </CardTitle>
                  <CardDescription>
                    Configure a visualização e comportamento do mapa
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="mapbox-token" className="flex items-center gap-2">
                      <Key className="w-4 h-4" />
                      Token do Mapbox
                    </Label>
                    <Input
                      id="mapbox-token"
                      type="password"
                      value={mapSettings.mapboxToken}
                      onChange={e => setMapSettings({ ...mapSettings, mapboxToken: e.target.value })}
                      placeholder="pk...."
                      className="bg-secondary/50 border-border/50 font-mono text-sm"
                    />
                    <p className="text-xs text-muted-foreground">
                      Obtenha seu token em{' '}
                      <a
                        href="https://account.mapbox.com/access-tokens/"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-primary hover:underline"
                      >
                        account.mapbox.com
                      </a>
                    </p>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="zoom">Zoom Padrão</Label>
                      <Select
                        value={mapSettings.defaultZoom}
                        onValueChange={value =>
                          setMapSettings({ ...mapSettings, defaultZoom: value })
                        }
                      >
                        <SelectTrigger className="bg-secondary/50 border-border/50">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="10">10 - Visão ampla</SelectItem>
                          <SelectItem value="11.5">11.5 - Padrão</SelectItem>
                          <SelectItem value="13">13 - Bairro</SelectItem>
                          <SelectItem value="15">15 - Rua</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="refresh">Intervalo de Atualização</Label>
                      <Select
                        value={mapSettings.refreshInterval}
                        onValueChange={value =>
                          setMapSettings({ ...mapSettings, refreshInterval: value })
                        }
                      >
                        <SelectTrigger className="bg-secondary/50 border-border/50">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="15">15 segundos</SelectItem>
                          <SelectItem value="30">30 segundos</SelectItem>
                          <SelectItem value="60">1 minuto</SelectItem>
                          <SelectItem value="300">5 minutos</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <h4 className="text-sm font-medium text-foreground">Camadas Padrão</h4>
                    <div className="space-y-3 pl-2">
                      <div className="flex items-center justify-between">
                        <Label className="font-normal">Mapa de Calor</Label>
                        <Switch
                          checked={mapSettings.showHeatmap}
                          onCheckedChange={checked =>
                            setMapSettings({ ...mapSettings, showHeatmap: checked })
                          }
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <Label className="font-normal">Áreas de Risco</Label>
                        <Switch
                          checked={mapSettings.showRiskAreas}
                          onCheckedChange={checked =>
                            setMapSettings({ ...mapSettings, showRiskAreas: checked })
                          }
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <Label className="font-normal">Pluviômetros</Label>
                        <Switch
                          checked={mapSettings.showPluviometers}
                          onCheckedChange={checked =>
                            setMapSettings({ ...mapSettings, showPluviometers: checked })
                          }
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <Label className="font-normal">Atualização Automática</Label>
                        <Switch
                          checked={mapSettings.autoRefresh}
                          onCheckedChange={checked =>
                            setMapSettings({ ...mapSettings, autoRefresh: checked })
                          }
                        />
                      </div>
                    </div>
                  </div>

                  <Button onClick={handleSaveMapSettings} className="gap-2">
                    <Save className="w-4 h-4" />
                    Salvar Configurações do Mapa
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Appearance Tab */}
            <TabsContent value="appearance">
              <Card className="bg-card/50 border-border/50">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Palette className="w-5 h-5 text-primary" />
                    Aparência
                  </CardTitle>
                  <CardDescription>
                    Personalize a aparência do dashboard
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-2">
                    <Label>Tema</Label>
                    <Select
                      value={theme.mode}
                      onValueChange={value => setTheme({ ...theme, mode: value })}
                    >
                      <SelectTrigger className="bg-secondary/50 border-border/50">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="dark">Escuro (Recomendado)</SelectItem>
                        <SelectItem value="light">Claro</SelectItem>
                        <SelectItem value="system">Sistema</SelectItem>
                      </SelectContent>
                    </Select>
                    <p className="text-xs text-muted-foreground">
                      O tema escuro é recomendado para reduzir fadiga visual durante longas jornadas
                    </p>
                  </div>

                  <div className="space-y-2">
                    <Label>Cor de Destaque</Label>
                    <div className="flex gap-2">
                      {['cyan', 'blue', 'green', 'purple', 'orange'].map(color => (
                        <button
                          key={color}
                          className={`w-8 h-8 rounded-full border-2 transition-all ${
                            theme.accentColor === color
                              ? 'border-foreground scale-110'
                              : 'border-transparent'
                          }`}
                          style={{
                            backgroundColor:
                              color === 'cyan'
                                ? '#22d3ee'
                                : color === 'blue'
                                ? '#3b82f6'
                                : color === 'green'
                                ? '#22c55e'
                                : color === 'purple'
                                ? '#a855f7'
                                : '#f97316',
                          }}
                          onClick={() => setTheme({ ...theme, accentColor: color })}
                        />
                      ))}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>Tamanho da Fonte</Label>
                    <Select
                      value={theme.fontSize}
                      onValueChange={value => setTheme({ ...theme, fontSize: value })}
                    >
                      <SelectTrigger className="bg-secondary/50 border-border/50">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="small">Pequeno</SelectItem>
                        <SelectItem value="medium">Médio</SelectItem>
                        <SelectItem value="large">Grande</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <Button onClick={handleSaveTheme} className="gap-2">
                    <Save className="w-4 h-4" />
                    Salvar Aparência
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
};

export default SettingsPage;